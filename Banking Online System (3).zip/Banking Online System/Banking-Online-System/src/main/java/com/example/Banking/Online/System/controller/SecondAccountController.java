package com.example.banking.online.system.controller;





import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.banking.online.system.model.SecondAccount;
import com.example.banking.online.system.services.SecondAccountServices;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class SecondAccountController{
    @Autowired

    SecondAccountServices  services;


    @GetMapping("/account")
    public List<SecondAccount>getAccounts(){
        return services.getAllAccounts();
    }

    @PostMapping("/login")
    public String saveAccount(@RequestBody SecondAccount  account){
        services.saveAccount(account);
        return "Success";
    }
}