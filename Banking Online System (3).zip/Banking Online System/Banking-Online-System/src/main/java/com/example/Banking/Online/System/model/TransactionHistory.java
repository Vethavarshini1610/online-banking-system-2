package com.example.banking.online.system.model;





import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class TransactionHistory{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;

    private String sendname;
    private String receivename;
    private double useramount;
    private LocalDate date;

    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }


    public String getSendname(){
        return sendname;
    }
    public void setSendname(String sendname){
        this.sendname=sendname;
    }
    public String getReceivename(){
        return receivename;
    }
    public void setReceivename(String receivename){
        this.receivename=receivename;
    }

    public double getUseramount(){
        return useramount;
    }
    public void setUseramount(double useramount){
        this.useramount=useramount;
    }
    public LocalDate getDate(){
        return date;
    }
    public void setDate(LocalDate date){
        this.date=date;
    }
}