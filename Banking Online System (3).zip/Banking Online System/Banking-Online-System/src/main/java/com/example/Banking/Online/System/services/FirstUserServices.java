package com.example.banking.online.system.services;





import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.banking.online.system.model.FirstUser;
import com.example.banking.online.system.repository.FirstUserRepo;

@Service

public class FirstUserServices{
    @Autowired
    FirstUserRepo repo;
    public List<FirstUser>getAllUsers(){
        return repo.findAll();
    }
    public FirstUser saveUser(FirstUser user){
        return repo.save(user);
    }
}