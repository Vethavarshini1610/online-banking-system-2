package com.example.banking.online.system.services;






import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.banking.online.system.model.SecondAccount;
import com.example.banking.online.system.repository.SecondAccountRepo;

@Service
public class SecondAccountServices{
    @Autowired
    SecondAccountRepo  repo;

    public List<SecondAccount>getAllAccounts(){
        return repo.findAll();
    }
    public SecondAccount saveAccount(SecondAccount account){
        return repo.save(account);
    }
}