package com.example.Banking.Online.System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingOnlineSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingOnlineSystemApplication.class, args);
	}

}
