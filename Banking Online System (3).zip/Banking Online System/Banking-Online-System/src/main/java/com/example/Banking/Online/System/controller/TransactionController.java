package com.example.banking.online.system.controller;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.banking.online.system.model.Transaction;
import com.example.banking.online.system.services.TransactionServices;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class TransactionController{
    @Autowired
    TransactionServices  services;

    @GetMapping("/transfer")
    public List<Transaction>getTransactions(){
        return services.getAllTransactions();
    }
    @PostMapping("/transaction")
    public String saveTransaction(@RequestBody Transaction transaction){
        services.saveTransaction(transaction);
        return "success";
    }
}