package com.example.banking.online.system.controller;






import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.banking.online.system.model.ViewAdmin;
import com.example.banking.online.system.services.ViewAdminServices;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class ViewAdminController{
    @Autowired
    ViewAdminServices  services;

    @GetMapping("/viewadmin")
    public List<ViewAdmin>getAdmin(){
        return services.getAllViewAdmin();
    }

    @PostMapping("/checkaccount")
    public String saveAdmin(@RequestBody ViewAdmin admin){
        services.saveAdmin(admin);
        return "success";
    }
}