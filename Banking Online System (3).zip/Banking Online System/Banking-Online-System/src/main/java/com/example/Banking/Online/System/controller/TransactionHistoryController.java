package com.example.banking.online.system.controller;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.banking.online.system.model.TransactionHistory;
import com.example.banking.online.system.services.TransactionHistoryServices;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class TransactionHistoryController{
    @Autowired
    TransactionHistoryServices  services;
    @GetMapping("/history")
    public List<TransactionHistory>getHistorys(){
        return services.getAllTransactionHistorys();
    }
    @PostMapping("/transactionhistory")
    public String saveHistroy(@RequestBody TransactionHistory history){
        services.saveHistory(history);
        return "success";
    }
}