package com.example.banking.online.system.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ViewAdmin{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;

    private String accountname;
    private String accountid;
    private double total;
    private String status;


    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }

    public String getAccountname(){
        return accountname;
    }
    public void setAccountname(String accountname){
        this.accountname=accountname;
    }
    public String getAccountid(){
        return accountid;
    }
    public void setAccountid(String accountid){
        this.accountid=accountid;
    }
    public double getTotal(){
        return total;
    }
    public void setTotal(double total){
        this.total=total;
    }
    public String getStatus(){
        return status;
    }
    public void setStatus(String status){
        this.status=status;
    }
}