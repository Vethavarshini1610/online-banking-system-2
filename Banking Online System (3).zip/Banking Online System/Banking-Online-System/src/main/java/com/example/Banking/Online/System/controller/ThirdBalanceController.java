package com.example.banking.online.system.controller;





import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.banking.online.system.model.ThirdBalance;
import com.example.banking.online.system.services.ThirdBalanceServices;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class ThirdBalanceController{
    @Autowired
    ThirdBalanceServices  services;

    @GetMapping("/balance")
    public List<ThirdBalance>getBalances(){
        return services.getAllBalances();
    }
    @PostMapping("/bankbalance")
    public String saveBalance(@RequestBody ThirdBalance balance){
        services.saveBalance(balance);
        return "Success";
    }


}