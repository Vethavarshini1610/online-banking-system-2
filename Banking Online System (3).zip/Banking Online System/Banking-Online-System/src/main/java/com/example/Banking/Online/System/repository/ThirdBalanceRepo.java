package com.example.banking.online.system.repository;





import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.banking.online.system.model.ThirdBalance;

@Repository
public interface ThirdBalanceRepo extends JpaRepository<ThirdBalance, Integer>{
    
}