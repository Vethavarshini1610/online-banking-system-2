package com.example.banking.online.system.model;





import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ThirdBalance{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;
    
    private String accountholdername;
    private double accountnumber;
    private double balance;


    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }

    public String getAccountholdername(){
        return accountholdername;
    }
    public void setAccountholdername(String accountholdername){
        this.accountholdername=accountholdername;
    }
    public double getAccountnumber(){
        return accountnumber;
    }
    public void setAccountnumber(double accountnumber){
        this.accountnumber=accountnumber;
    }
    public double getBalance(){
        return balance;
    }
    public void setBalance(double balance){
        this.balance=balance;
    }
}