package com.example.banking.online.system.services;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.banking.online.system.model.TransactionHistory;
import com.example.banking.online.system.repository.TransactionHistoryRepo;

@Service
public class TransactionHistoryServices{
    @Autowired
    TransactionHistoryRepo repo;
    public List<TransactionHistory>getAllTransactionHistorys(){
        return repo.findAll();
    }
    public TransactionHistory saveHistory(TransactionHistory history){
        return repo.save(history);
    }
}