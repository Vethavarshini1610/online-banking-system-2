package com.example.banking.online.system.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.banking.online.system.model.Transaction;
import com.example.banking.online.system.repository.TransactionRepo;

@Service
public class TransactionServices{
    @Autowired
    TransactionRepo repo;
    public List<Transaction>getAllTransactions(){
        return repo.findAll();
    }
    public Transaction saveTransaction(Transaction  transaction){
        return repo.save(transaction);
    }
}