package com.example.banking.online.system.services;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.banking.online.system.model.ViewAdmin;
import com.example.banking.online.system.repository.ViewAdminRepo;


@Service
public class ViewAdminServices{
    @Autowired

    ViewAdminRepo   repo;

    public List<ViewAdmin>getAllViewAdmin(){
        return repo.findAll();
    }
    public ViewAdmin saveAdmin (ViewAdmin admin){
        return repo.save(admin);
    }
}