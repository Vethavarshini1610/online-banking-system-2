function viewdetails(){
    var accountname=document.getElementById("accountname").value;
    var accountid=document.getElementById("accountid").value;
    var totalbalance=document.getElementById("totalbalance").value;
    var status=document.getElementById("status").value;

    if(accountname===""||accountid===""||totalbalance===""||status===""){
        alert("Please Enter the Details");
        return;
    }
    fetch('http://localhost:8080/api/checkaccount', {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            accountname: accountname,
            accountid: accountid,
            totalbalance: totalbalance,
            type: status
        })
    })
        .then(res => res.text())
        .then(data => {
            if (data === "success") {
                alert("Successfully Upload");
            } else {
                alert("Its Error ");
            }
        });

}