
function submit(){
    var name=document.getElementById("name").value;
    var userid=document.getElementById("number").value;
    var accountnumber=document.getElementById("accountnumber").value;
    var initialamount=document.getElementById("initialamount").value;

    if(name==="" || accountnumber ==="" ||userid==="" ||initialamount===""){
        alert("Fill all Fields");
        return;
    }
    localStorage.setItem("loggeduser",name);
    localStorage.setItem("accountnumber",accountnumber);
    localStorage.setItem("initialamount",initialamount);

    fetch('http://localhost:8080/api/login',{
        method:"POST",
        headers:{
            "Content-Type":"application/json"
                },
                body:JSON.stringify({
                    name:name,
                    userID:userid,
                    accountnumber:accountnumber,
                    initialamount:initialamount
                })
    })
    .then(res=>res.text())
    .then(data=>{
        if(data==="success"){
            alert("Successfully Upload");
        }else{
            alert("Its Error ");
        }
    });
   
    window.location.href="page2.html";

}