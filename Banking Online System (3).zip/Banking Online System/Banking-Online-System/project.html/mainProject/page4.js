function savebutton(){
  var username=document.getElementById("Username").value;
  var userid=document.getElementById("userid").value;
  var sendamount=document.getElementById("sendamount").value;
  var receivedamount=document.getElementById("receiveamount").value;


  if(username===""||userid===""||sendamount===""||receivedamount===""){
    alert("please Enter the Form");
    return;
  }

  fetch('http://localhost:8080/api/transactionhistory', {
    method: "POST",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify({
        username: username,
        userid: userid,
        sendamount: sendamount,
        receivedamount: receivedamount
    })
})
    .then(res => res.text())
    .then(data => {
        if (data === "success") {
            alert("Successfully Upload");
        } else {
            alert("Its Error ");
        }
    });
 
}



 