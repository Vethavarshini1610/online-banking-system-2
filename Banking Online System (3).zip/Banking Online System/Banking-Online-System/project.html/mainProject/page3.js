function payamount(){
    let sender=document.getElementById("sender").value;
    let receiver=document.getElementById("receiver").value;
    let amount=document.getElementById("amount").value;

    if(sender===""|| receiver===""|| amount===""){
        alert("Please Enter the Details");
        return;
    }

    document.querySelector(".overlay").style.display="block";
    document.querySelector(".popup").style.display="block"



    fetch('http://localhost:8080/api/transaction', {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            sender: sender,
            receiver: receiver,
            amount: amount
            
        })
    })
        .then(res => res.text())
        .then(data => {
            if (data === "success") {
                alert("Successfully Upload");
            } else {
                alert("Its Error ");
            }
        });
}
function closepopup(){
    document.querySelector(".overlay").style.display="none";
    document.querySelector(".popup").style.display="none";
}