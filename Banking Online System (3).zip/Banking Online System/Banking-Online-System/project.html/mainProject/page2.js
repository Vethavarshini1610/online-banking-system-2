function balanceshow(){
var accountholdername=document.getElementById("accountname").value;
var accountnumber=document.getElementById("accnumber");
var balance=document.getElementById("balance")

if(accountholdername===""||accountnumber===""||balance===""){
    alert("Enter the Details Correctly")
}




fetch('http://localhost:8080/api/login',{
    method:"POST",
    headers:{
        "Content-Type":"application/json"
            },
            body:JSON.stringify({
                name:accountholdername,
                accnumber:accnumber,
                balance:balance
            })
})
.then(res=>res.text())
.then(data=>{
    if(data==="success"){
        alert("Successfully Upload");
    }else{
        alert("Its Error ");
    }
});


}
